
#ifndef mq3
#define mq3


void MQ3setup();
int getMQ3();

#endif
