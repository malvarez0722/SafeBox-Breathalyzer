# SafeBox-Breathalyzer
A box that is opened by a successful puff at the breathalyzer.
