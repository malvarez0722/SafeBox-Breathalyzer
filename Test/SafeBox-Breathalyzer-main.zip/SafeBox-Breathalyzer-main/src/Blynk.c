// -------------------------------------------------------------------
// File name: Blynk.c
// Description: This code is used to bridge the TM4C123 board and the Blynk Application
//              via the ESP8266 WiFi board
// Author: Mark McDermott and Andrew Lynch (Arduino source)
// Converted to EE445L style Jonathan Valvano
// Orig gen date: May 21, 2018
// Last update: Sept 20, 2018
//
// Download latest Blynk library here:
//   https://github.com/blynkkk/blynk-library/releases/latest
//
//  Blynk is a platform with iOS and Android apps to control
//  Arduino, Raspberry Pi and the likes over the Internet.
//  You can easily build graphic interfaces for all your
//  projects by simply dragging and dropping widgets.
//
//   Downloads, docs, tutorials: http://www.blynk.cc
//   Sketch generator:           http://examples.blynk.cc
//   Blynk community:            http://community.blynk.cc
//
//------------------------------------------------------------------------------

// TM4C123       ESP8266-ESP01 (2 by 4 header)
// PE5 (U5TX) to Pin 1 (Rx)
// PE4 (U5RX) to Pin 5 (TX)
// PE3 output debugging
// PE2 nc
// PE1 output    Pin 7 Reset
// PE0 input     Pin 3 Rdy IO2
//               Pin 2 IO0, 10k pullup to 3.3V  
//               Pin 8 Vcc, 3.3V (separate supply from LaunchPad 
// Gnd           Pin 4 Gnd  
// Place a 4.7uF tantalum and 0.1 ceramic next to ESP8266 3.3V power pin
// Use LM2937-3.3 and two 4.7 uF capacitors to convert USB +5V to 3.3V for the ESP8266
// http://www.ti.com/lit/ds/symlink/lm2937-3.3.pdf

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "../inc/Blynk.h"
#include "../inc/tm4c123gh6pm.h"
#include "../inc/ST7735.h"
#include "../inc/PLL.h"
#include "../inc/UART.h"
#include "../inc/PortF.h"
#include "../inc/esp8266.h"
#include "../inc/PWM.h"
#include "../inc/CortexM.h"
#include "../inc/Latch.h"

uint32_t LED;      // VP1
uint32_t LastF;    // VP74
uint32_t alcoholLimit = 0;
int pinFlag = 0;

uint32_t pin_num = 0; 
uint32_t pin_int = 0;
 

uint32_t pin_1 = 0;
uint32_t pin_2 = 0;
uint32_t pin_3 = 0;
uint32_t pin_4 = 0;
uint32_t pin_7 = 0;

// These 6 variables contain the most recent Blynk to TM4C123 message
// Blynk to TM4C123 uses VP0 to VP15
char serial_buf[64];
char Pin_Number[2]   = "99";       // Initialize to invalid pin number
char Pin_Integer[8]  = "0000";     //
char Pin_Float[8]    = "0.0000";   //

void TM4C_to_Blynk(uint32_t pin,uint32_t value){
  if((pin < 70)||(pin > 99)){
    return; // ignore illegal requests
  }
// your account will be temporarily halted 
  // if you send too much data
  ESP8266_OutUDec(pin);       // Send the Virtual Pin #
  ESP8266_OutChar(',');
  ESP8266_OutUDec(value);      // Send the current value
  ESP8266_OutChar(',');
  ESP8266_OutString("0.0\n");  // Null value not used in this example
}


void Blynk_to_TM4C(void){int j; char data;
// Check to see if a there is data in the RXD buffer
  if(ESP8266_GetMessage(serial_buf)){  // returns false if no message
    // Read the data from the UART5
#ifdef DEBUG1
    j = 0;
    do{
      data = serial_buf[j];
      UART_OutChar(data);        // Debug only
      j++;
    }while(data != '\n');
    UART_OutChar('\r');        
#endif
           
// Rip the 3 fields out of the CSV data. The sequence of data from the 8266 is:
// Pin #, Integer Value, Float Value.
    strcpy(Pin_Number, strtok(serial_buf, ","));
    strcpy(Pin_Integer, strtok(NULL, ","));       // Integer value that is determined by the Blynk App
    strcpy(Pin_Float, strtok(NULL, ","));         // Not used
    pin_num = atoi(Pin_Number);     // Need to convert ASCII to integer
    pin_int = atoi(Pin_Integer); 

		switch(pin_num){
			case 1: pin_1 = pin_int;
							break;
			case 2: pin_2 = pin_int;
							break;
			case 3: pin_3 = pin_int;
							break;
			case 4: pin_4 = pin_int;
							break;
			case 9: pin_7 = pin_int;
							break;
			default: break;	
		} 
		
#ifdef DEBUG1
    UART_OutString(" Pin_Number = ");
    UART_OutString(Pin_Number);
    UART_OutString("   Pin_Integer = ");
    UART_OutString(Pin_Integer);
    UART_OutString("   Pin_Float = ");
    UART_OutString(Pin_Float);
    UART_OutString("\n\r");
#endif
		pinFlag = pin_num;
	}
}

void SendInformation(void){
  uint32_t thisF;
  thisF = PortF_Input();
// your account will be temporarily halted if you send too much data
  if(thisF != LastF){
#ifdef DEBUG3
    TM4C_to_Blynk(74, thisF);  // VP74
		UART_OutString("press");
//    Output_Color(ST7735_WHITE);
//    ST7735_OutString("Send 74 data=");
//    ST7735_OutUDec(thisF);
//    ST7735_OutChar('\n');
#endif
  }
  LastF = thisF;
}


