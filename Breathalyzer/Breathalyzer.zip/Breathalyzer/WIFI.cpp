
/* Comment this out to disable prints and save space */
#define BLYNK_PRINT Serial
#include "WIFI.h"
#include <ESP8266WiFi.h>
#include <stdio.h>
#include <string.h>
#include <BlynkSimpleEsp8266.h>

// You should get Auth Token in the Blynk App.
// Go to the Project Settings (nut icon).
char auth[] = "iP34HYmryD_CBD21JtIZuGEJDWQ0Xr9h";
//char auth[] = "yDHtH6c12TNOjPfXTreouRCWPsOLWfbk";

// Your WiFi credentials.
// Set password to "" for open networks.
//char ssid[] = "ATTtejmpDS";
//char pass[] = "+paz8dtsh#tw";

//char ssid[] = "SpectrumSetup-FB";
//char pass[] = "statuecosmic865";

char ssid[] = "Adrian_Laptop";
char pass[] = "97ac73538";

WIFI::WIFI(){

}

WidgetBridge bridge1(V8);
void WIFI::SetupWIFI()
{
  Blynk.begin(auth, ssid, pass);
  // You can also specify server:
  //Blynk.begin(auth, ssid, pass, "blynk-cloud.com", 80);
  //Blynk.begin(auth, ssid, pass, IPAddress(192,168,1,100), 8080);
}

BLYNK_CONNECTED(){
  bridge1.setAuthToken("FyOxfJnTi0T5d-WAduC5urB751KMauqH");
}
void WIFI::BlynkWrite(int num)
{
  Blynk.run();
  Blynk.virtualWrite(7, num);
  bridge1.virtualWrite(V9,num);
}

//int value;
//BLYNK_WRITE(V7){
//    value = param.asInt(); // Get value as integer
//}

void WIFI::BlynkRead(){
}
