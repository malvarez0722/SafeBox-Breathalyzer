#include <stdio.h>
#include <string.h>
#include "UI.h"
#include "MQ3.h"
#include <Arduino.h>

const int analogInPin = A0;

int m1 = 0;
int m2 = 0;
int m3 = 0;
int m4 = 0;
int m5 = 0;
int MQ3avg = 0;

void readVals(){
  // read the analog in value
 // digitalWrite(3, LOW);
  m5=m4; m4=m3; m3=m2; m2=m1;
  
  m1 = analogRead(analogInPin);
  MQ3avg = (m1+m2+m3+m4+m5)/5; 
}


///////////////
int getMQ3(){
  return MQ3avg;
}
