
#ifndef ui
#define ui


void UI_interruptSetup();
void ButtonISR();
void SetLED(int num);

#endif
