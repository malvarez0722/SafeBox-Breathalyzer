
#ifndef mq3
#define mq3


//void MQ3setup();
void readVals();
int getMQ3();

#endif
